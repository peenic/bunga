# JavaScript chat room tutorial

These are the project files for the [JavaScript chat room tutorial](https://www.scaledrone.com/blog/posts/javascript-chat-room-tutorial).

To run this example make sure to replace the `CLIENT_ID` in [`script.js`](https://github.com/ScaleDrone/javascript-chat-room-tutorial/blob/master/script.js)
